library(deSolve)

## load observed data ----------------------------------------------------------

df_cases <- read.csv("simple_sir_cases.csv")
obs_cases <- df_cases$cases
plot(obs_cases, xlab = "time", ylab = "new cases")

## ODE equations for simple SIR model ------------------------------------------

sir_model <- function(t, state, parms) {
  with(as.list(c(state, parms)), {
    N <- S+I+R
    lambda <- beta*I/N
    
    mu <- 1/80 # death rate
    
    dS <- mu*N - lambda*S - mu*S
    dI <- lambda*S - gamma*I - mu*I
    dR <- gamma*I - mu*R
    
    dY <- lambda*S
    
    list(c(dS, dI, dR, dY))
  })
}

## define prior function -------------------------------------------------------

prior <- function(R0) {
  R0_prior <- dunif(R0, min=1, max=3, log = TRUE)
  return(R0_prior)
}

## function to compute likelihood ----------------------------------------------

likelihood <- function(R0) {
  # assume gamma and mu known
  gamma <- 0.2
  mu <- 1/80
  # compute beta from R0
  beta <- R0 * (gamma + mu)
  # solve ODE system using beta and gamma
  out <- ode(y = c(S = 9999, I = 1, R = 0, Y = 0),
             times = 0:500, func = sir_model, parms = c(beta = beta, gamma = gamma))
  # extract new cases over time from the ODE solution
  pred_cases <- diff(out[, 5])
  pred_cases[pred_cases < 0] <- 0
  # compute Poisson likelihood
  return(sum(dpois(obs_cases, pred_cases + 1e-20), log = TRUE))
}

## function to compute posterior -----------------------------------------------

posterior <- function(R0) {
  return(likelihood(R0) + prior(R0))
}

## grid approximation ----------------------------------------------------------

R0_grid <- seq(1, 3, length.out = 100)
R0_posterior <- sapply(R0_grid, posterior)
R0_posterior <- exp(R0_posterior)
R0_posterior <- R0_posterior / sum(R0_posterior)

plot(R0_grid, R0_posterior, type = "l")




