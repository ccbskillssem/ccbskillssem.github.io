library(deSolve)
library(scales)

## load observed data ----------------------------------------------------------

df_cases <- read.csv("simple_sir_cases.csv")
obs_cases <- df_cases$cases
plot(obs_cases, xlab = "time", ylab = "new cases")

## ODE equations for simple SIR model ------------------------------------------

sir_model <- function(t, state, parms) {
  with(as.list(c(state, parms)), {
    N <- S+I+R
    lambda <- beta*I/N
    
    mu <- 1/80 # death rate
    
    dS <- mu*N - lambda*S - mu*S
    dI <- lambda*S - gamma*I - mu*I
    dR <- gamma*I - mu*R
    
    dY <- lambda*S
    
    list(c(dS, dI, dR, dY))
  })
}

## define prior function -------------------------------------------------------

prior <- function(R0) {
  R0_prior <- dunif(R0, min=0, max=4, log = TRUE)
  return(R0_prior)
}

## function to compute likelihood ----------------------------------------------

likelihood <- function(R0) {
  # assume gamma and mu known
  gamma <- 0.2
  mu <- 1/80
  # compute beta from R0
  beta <- R0 * (gamma + mu)
  # solve ODE system using beta and gamma
  out <- ode(y = c(S = 9999, I = 1, R = 0, Y = 0),
             times = 0:500, func = sir_model, parms = c(beta = beta, gamma = gamma))
  # extract new cases over time from the ODE solution
  pred_cases <- diff(out[, 5])
  pred_cases[pred_cases < 0] <- 0
  # compute Poisson likelihood
  return(sum(dpois(obs_cases, pred_cases + 1e-20), log = TRUE))
}

## function to compute posterior -----------------------------------------------

posterior <- function(R0) {
  return(likelihood(R0) + prior(R0))
}

## proposal function -----------------------------------------------------------

proposal <- function(R0) {
  return(rnorm(1, mean = R0, sd = 0.05))
}

## run Metropolis-Hastings sampling --------------------------------------------

run_MCMC <- function(R0, iterations) {
  
  # initialize chain
  chain <- rep(NA, iterations+1)
  chain[1] <- R0
  
  # run MCMC sampling
  for (i in 1:iterations) {
    
    cur_R0 <- chain[i]
    
    # propose a new R0
    new_R0 <- proposal(cur_R0)
    
    # compute jump probability
    prob_jump <- exp(posterior(new_R0) - posterior(cur_R0))
    
    if (runif(1) < prob_jump) {
      # jump to new R0
      chain[i+1] <- new_R0
    } else {
      # stay at current R0
      chain[i+1] <- cur_R0
    }
  }
  
  return(chain)
}

# run MCMC sampling
set.seed(123)
out_MCMC <- run_MCMC(R0 = 3, iterations = 2000)
plot(out_MCMC, type = "l", xlab = "iteration", ylab = "R0")

# remove burn-in samples
MCMC_samples <- out_MCMC[-(1:500)]
plot(MCMC_samples, type = "l", xlab = "iteration", ylab = "R0")
hist(MCMC_samples, xlab = "R0", xlim = c(1, 3))

# extract 95% credible interval
quantile(MCMC_samples, probs = c(0.025, 0.5, 0.975))

# extract a subset of MCMC samples for posterior plotting
set.seed(123)
MCMC_samples_subset <- sample(MCMC_samples, size = 100, replace = FALSE)

# posterior simulated trajectories
plot(obs_cases, xlab = "time", ylab = "new cases", col = alpha("black", 0.2))
for (R0 in MCMC_samples_subset) {
  
  # solve ODE
  beta <- R0 * (0.2 + 1/80)
  # solve ODE system using beta and gamma
  out <- ode(y = c(S = 9999, I = 1, R = 0, Y = 0),
             times = 0:500, func = sir_model, parms = c(beta = beta, gamma = 0.2))
  # extract new cases over time from the ODE solution
  pred_cases <- diff(out[, 5])
  pred_cases[pred_cases < 0] <- 0
  # plot predicted trajectory
  lines(pred_cases, type = "l", col=alpha("red", 0.05))
  
}

# sample prior R0 values
set.seed(123)
prior_samples <- runif(100, min = 0, max = 4)

# prior simulated trajectories
plot(obs_cases, xlab = "time", ylab = "new cases", col = alpha("black", 0.2))
for (R0 in prior_samples) {
  
  # solve ODE
  beta <- R0 * (0.2 + 1/80)
  # solve ODE system using beta and gamma
  out <- ode(y = c(S = 9999, I = 1, R = 0, Y = 0),
             times = 0:500, func = sir_model, parms = c(beta = beta, gamma = 0.2))
  # extract new cases over time from the ODE solution
  pred_cases <- diff(out[, 5])
  pred_cases[pred_cases < 0] <- 0
  # plot predicted trajectory
  lines(pred_cases, type = "l", col=alpha("red", 0.05))
  
}
