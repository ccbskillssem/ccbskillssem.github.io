## Globe tossing example

# define grid of p values
p_grid <- seq(0, 1, length.out = 50)

# define prior
prior <- rep(1, 50)

# define likelihood (W = 6, L = 3)
likelihood <- dbinom(6, size = 9, prob = p_grid)

# compute posterior
posterior <- likelihood * prior
posterior <- posterior / sum(posterior)
plot(p_grid, posterior, type = "l",
     xlab = "probability of water", ylab = "posterior probability")

# obtain samples
p_samples <- sample(p_grid, prob = posterior, size = 1e+4, replace = TRUE)
hist(p_samples)

# median sampled prob value
quantile(p_samples, 0.5)

# 95% credible interval
quantile(p_samples, probs = c(0.025, 0.975))

